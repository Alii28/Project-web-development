<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $kodeTRAVEL = $_GET["hapus"];
    mysqli_query($connection, "delete from travel where kodeTRAVEL = '$kodeTRAVEL'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index5.php");
}
?>