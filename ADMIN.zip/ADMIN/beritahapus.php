<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $hotel0115 = $_GET["hapus"];
    mysqli_query($connection, "delete from berita where berita0115 = '$berita0115'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index8.php");
}
?>