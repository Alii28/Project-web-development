<!DOCTYPE html>
<html>

<?php
include "include/config.php";

if (isset($_GET['ubah'])) {
    $kode_produk = $_GET['ubah'];

    // Ambil data dari database berdasarkan kode produk
    $query = mysqli_query($connection, "SELECT * FROM pusatoleholeh WHERE pusatKODE='$kode_produk'");
    $data = mysqli_fetch_assoc($query);

    if (isset($_POST['Simpan'])) {
        // Update data di database
        $pusatKODE = $_POST['pusatKODE'];
        $pusatNAMA = $_POST['pusatNAMA'];
        $pusatALAMAT = $_POST['pusatALAMAT'];
        $merkPRODUK = $_POST['merkPRODUK'];
        header("location:index4.php");

        mysqli_query($connection, "UPDATE pusatoleholeh SET pusatNAMA='$pusatNAMA', pusatALAMAT='$pusatALAMAT', merkPRODUK='$merkPRODUK' WHERE pusatKODE='$pusatKODE'");

        echo '<script>alert("Update successful!"); window.location.href = "pusatoleholeh.php";</script>';
        exit();
    }
}
?>

<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
</head>

<body>
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <header>
                <h1 style="background:black; color:white; height:80px;">Pusat Oleh-Oleh</h1>
            </header>
            <form method="POST">
                <div class="mb-3 row">
                    <label for="pusatKODE" class="col-sm-2 col-form-label">Kode Produk</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pusatKODE" name="pusatKODE" value="<?php echo $data['pusatKODE']; ?>" readonly>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="pusatNAMA" class="col-sm-2 col-form-label">Nama Tempat</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pusatNAMA" name="pusatNAMA" value="<?php echo $data['pusatNAMA']; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="pusatALAMAT" class="col-sm-2 col-form-label">Alamat Tempat</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pusatALAMAT" name="pusatALAMAT" value="<?php echo $data['pusatALAMAT']; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="merkPRODUK" class="col-sm-2 col-form-label">Merk Produk</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="merkPRODUK" name="merkPRODUK" value="<?php echo $data['merkPRODUK']; ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <input type="submit" class="btn btn-primary" value="Simpan" name="Simpan">
                        <input type="button" class="btn btn-secondary" value="Batal" onclick="history.back()">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</body>

</html>
