<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $hotel0115 = $_GET["hapus"];
    mysqli_query($connection, "delete from ali where hotel0115 = '$hotel0115'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index.php");
}
?>