<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $restoranKODE = $_GET["hapus"];
    mysqli_query($connection, "delete from restoran where restoranKODE = '$restoranKODE'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index3.php");
}
?>