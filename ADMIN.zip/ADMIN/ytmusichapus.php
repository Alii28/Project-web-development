<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $pelangganID = $_GET["hapus"];
    mysqli_query($connection, "delete from ytmusic where pelangganID = '$pelangganID'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index2.php");
}
?>