<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $sayyidinaaID = $_GET["hapus"];
    mysqli_query($connection, "delete from sayyidinaa where sayyidinaaID = '$sayyidinaaID'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index8.php");
}
?>