<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $kategoriKODE = $_GET["hapus"];
    mysqli_query($connection, "delete from kategoriwisata where kategoriKODE = '$kategoriKODE'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:kategoriwisata.php");
}
?>