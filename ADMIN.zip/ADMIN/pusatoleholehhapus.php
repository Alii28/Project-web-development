<?php
    include "include/config.php";
    if(isset($_GET['hapus']))
{
    $pusatKODE = $_GET["hapus"];
    mysqli_query($connection, "delete from pusatoleholeh where pusatKODE = '$pusatKODE'");
    echo "<script>alert('DATA BERHASIL DIHAPUS')</script>";
    header("location:index4.php");
}
?>