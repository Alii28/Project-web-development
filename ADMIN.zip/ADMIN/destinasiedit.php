<!DOCTYPE html>
<html>

<?php
include 'include/config.php';

if (isset($_GET['ubah'])) {
    $kodeDestinasi = $_GET['ubah'];
    $query = mysqli_query($connection, "select * from destinasi where destinasiKODE='$kodeDestinasi'");
    $data = mysqli_fetch_array($query);
}

if (isset($_POST['Update'])) {
    $destinasiKODE = $_POST['kodedestinasi'];
    $destinasiNAMA = $_POST['namadestinasi'];
    $kategoriKODE = $_POST['kodekategori'];

    mysqli_query($connection, "update destinasi set destinasiNAMA='$destinasiNAMA', kategoriKODE='$kategoriKODE' where destinasiKODE='$destinasiKODE'");
    header("location: index1.php");
}

$datakategori = mysqli_query($connection, "select * from kategoriwisata");
?>

<head>
    <title>EDIT DESTINASI</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
</head>

<body>

    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">

            <header>
                <h1 style="background:blue; color:white; height:80px;">EDIT DESTINASI</h1>
            </header>

            <form method="POST">
                <div class="mb-3 row">
                    <label for="kodedestinasi" class="col-sm-2 col-form-label">Kode Destinasi</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="kodedestinasi" id="kodedestinasi" value="<?php echo $data['destinasiKODE']; ?>" readonly>
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="namadestinasi" class="col-sm-2 col-form-label">Nama Destinasi</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="namadestinasi" id="namadestinasi" value="<?php echo $data['destinasiNAMA']; ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="kodekategori" class="col-sm-2 col-form-label">Kategori Wisata</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="kodekategori" id="kodekategori">
                            <?php while ($row = mysqli_fetch_array($datakategori)) { ?>
                                <option value="<?php echo $row["kategoriKODE"] ?>" <?php if ($row["kategoriKODE"] == $data['kategoriKODE']) echo 'selected="selected"'; ?>>
                                    <?php echo $row["kategoriKODE"] . ' - ' . $row["kategoriNAMA"] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <input type="submit" class="btn btn-primary" value="Update" name="Update">
                        <a href="destinasi.php" class="btn btn-secondary">Batal</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#kodekategori').select2({
                closeOnSelect: true,
                allowClear: true,
                placeholder: 'Pilih Kategori Wisata'
            });
        });
    </script>

</body>

</html>
