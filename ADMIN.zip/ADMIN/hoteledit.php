<!DOCTYPE html>
<html>

<?php
include "include/config.php";

if (isset($_GET['ubah'])) {
    $kodeHotel = $_GET['ubah'];
    $query = mysqli_query($connection, "select * from ali where hotel0115='$kodeHotel'");
    $data = mysqli_fetch_array($query);
}

if (isset($_POST['Update'])) {
    $hotel0115 = $_POST['hotel0115'];
    $hotelnama = $_POST['hotelnama'];
    $hotelalamat = $_POST['hotelalamat'];
    $kategori0115 = $_POST['kategori0115'];
    mysqli_query($connection, "update ali set hotelNAMA='$hotelnama', hotelALAMAT='$hotelalamat', kategori0115='$kategori0115' where hotel0115='$hotel0115'");
    header("location: index.php");
}
?>

<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
</head>

<body>
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <header>
                <h1 style="background:blue; color:white; height:80px;">EDIT HOTEL</h1>
            </header>

            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <form method="POST">
                        <div class="mb-3 row">
                            <label for="hotel0115" class="col-sm-2 col-form-label">Kode Hotel</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="hotel0115" name="hotel0115" value="<?php echo $data['hotel0115']; ?>" readonly>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="hotelnama" class="col-sm-2 col-form-label">Nama Hotel</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="hotelnama" name="hotelnama" value="<?php echo $data['hotelNAMA']; ?>">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="hotelalamat" class="col-sm-2 col-form-label">Alamat Hotel</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="hotelalamat" name="hotelalamat" value="<?php echo $data['hotelALAMAT']; ?>">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="kategori0115" class="col-sm-2 col-form-label">Kategori Kode</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="kategori0115" name="kategori0115" value="<?php echo $data['kategori0115']; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-10">
                                <input type="submit" class="btn btn-primary" value="Update" name="Update">
                                <a href="hotel.php" class="btn btn-secondary">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</body>
</html>
