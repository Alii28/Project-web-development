<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Travel</title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<?php
include "include/config.php";

if (isset($_GET['ubah'])) {
    $kodeTravel = $_GET['ubah'];
    $query = mysqli_query($connection, "SELECT * FROM travel WHERE kodeTRAVEL='$kodeTravel'");
    $data = mysqli_fetch_array($query);
    
}

if (isset($_POST['Update'])) {
    $kodeTravel = $_POST['inputkode'];
    $namaTravel = $_POST['inputnama'];
    $destinasiTravel = $_POST['inputalamat'];
    header("location:index5.php");

    // Jika ada file yang diunggah, proses file
    if ($_FILES['file']['name']) {
        $namafile = $_FILES['file']['name'];
        $file_tmp = $_FILES["file"]["tmp_name"];

        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);

        // PERIKSA EKSTENSI FILE HARUS JPG ATAU JPEG
        if (($ekstensifile == "jpg") or ($ekstensifile == "jpeg")) {
            move_uploaded_file($file_tmp, 'images/' . $namafile); // unggah file ke folder images
            mysqli_query($connection, "UPDATE travel SET namaTRAVEL='$namaTravel', fotoTRAVEL='$namafile', destinasiTRAVEL='$destinasiTravel' WHERE kodeTRAVEL='$kodeTravel'");
            echo '<script>alert("Update successful!"); window.location.href = "travel.php";</script>';
            exit();
        } else {
            echo '<script>alert("File harus berformat JPG atau JPEG!"); window.location.href = "travel.php";</script>';
            exit();
        }
    } else {
        // Jika tidak ada file yang diunggah, update data tanpa mengubah foto
        mysqli_query($connection, "UPDATE travel SET namaTRAVEL='$namaTravel', destinasiTRAVEL='$destinasiTravel' WHERE kodeTRAVEL='$kodeTravel'");
        echo '<script>alert("Update successful!"); window.location.href = "travel.php";</script>';
        exit();
    }
}
?>

<body>
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                    <h1 class="display-4">Edit Travel</h1>
                </div>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group row">
                    <label for="kodeTravel" class="col-sm-2 col-form-label">Kode Travel</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="kodeTravel" name="inputkode" value="<?php echo $data['kodeTRAVEL']; ?>" readonly>
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="namaTravel" class="col-sm-2 col-form-label">Nama Travel</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="namaTravel" name="inputnama" value="<?php echo $data['namaTRAVEL']; ?>">
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="destinasiTravel" class="col-sm-2 col-form-label">Destinasi Travel</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="destinasiTravel" name="inputalamat" value="<?php echo $data['destinasiTRAVEL']; ?>">
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="file" class="col-sm-2 col-form-label">Foto Travel</label>
                    <div class="col-sm-10">
                        <input type="file" id="file" name="file">
                        <p class="help-block">Field ini digunakan untuk unggah file</p>
                        <?php if ($data['fotoTRAVEL']) { ?>
                            <p>Foto saat ini: <img src="images/<?php echo $data['fotoTRAVEL']; ?>" width="80"></p>
                        <?php } else {
                            echo "<p>Foto saat ini: Tidak ada foto</p>";
                        } ?>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <input type="submit" name="Update" class="btn btn-primary" value="Update">
                        <a href="travel.php" class="btn btn-secondary">Batal</a>
                    </div>
                </div>
            </form>
            <br>
        </div>

        <div class="col-sm-1"></div>
    </div>

    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
</body>

</html>
