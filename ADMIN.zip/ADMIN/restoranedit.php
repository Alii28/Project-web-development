<!DOCTYPE html>
<html>

<?php
include "include/config.php";

if (isset($_GET['ubah'])) {
    $koderestoran = $_GET['ubah'];
    $query = mysqli_query($connection, "select * from restoran where restoranKODE='$koderestoran'");
    $data = mysqli_fetch_array($query);
}

if (isset($_POST['Update'])) {
    $koderestoran = $_POST['inputkode'];
    $namarestoran = $_POST['inputnama'];
    $alamatrestoran = $_POST['inputalamat'];
    header("location:index3.php");
    // Jika ada file yang diunggah, proses file
    if ($_FILES['file']['name']) {
        $namafile = $_FILES['file']['name'];
        $file_tmp = $_FILES["file"]["tmp_name"];

        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);

        // PERIKSA EKSTENSI FILE HARUS JPG ATAU JPEG
        if (($ekstensifile == "jpg") or ($ekstensifile == "jpeg")) {
            move_uploaded_file($file_tmp, 'images/' . $namafile); // unggah file ke folder images
            mysqli_query($connection, "UPDATE restoran SET restoranNAMA='$namarestoran', restoranFOTO='$namafile', restoranALAMAT='$alamatrestoran' WHERE restoranKODE='$koderestoran'");
            echo '<script>alert("Update successful!"); window.location.href = "restoran.php";</script>';
            exit();
        } else {
            echo '<script>alert("File harus berformat JPG atau JPEG!"); window.location.href = "restoran.php";</script>';
            exit();
        }
    } else {
        // Jika tidak ada file yang diunggah, update data tanpa mengubah foto
        mysqli_query($connection, "UPDATE restoran SET restoranNAMA='$namarestoran', restoranALAMAT='$alamatrestoran' WHERE restoranKODE='$koderestoran'");
        echo '<script>alert("Update successful!"); window.location.href = "restoran.php";</script>';
        exit();
    }
}
?>

<head>
    <title>EDIT RESTORAN WISATA</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" />
</head>

<body>
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                    <h1 class="display-4">Edit Restoran Wisata</h1>
                </div>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group row">
                    <label for="koderestoran" class="col-sm-2 col-form-label">Kode Restoran</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="koderestoran" name="inputkode" value="<?php echo $data['restoranKODE']; ?>" readonly>
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="namarestoran" class="col-sm-2 col-form-label">Nama Restoran</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="namarestoran" name="inputnama" value="<?php echo $data['restoranNAMA']; ?>">
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="alamatrestoran" class="col-sm-2 col-form-label">Alamat Restoran</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="alamatrestoran" name="inputalamat" value="<?php echo $data['restoranALAMAT']; ?>">
                    </div>
                </div>
                <br>
                <div class="form-group row">
                    <label for="file" class="col-sm-2 col-form-label">Foto Restoran</label>
                    <div class="col-sm-10">
                        <input type="file" id="file" name="file">
                        <p class="help-block">Field ini digunakan untuk unggah file</p>
                        <?php if ($data['restoranFOTO']) { ?>
                            <p>Foto saat ini: <img src="images/<?php echo $data['restoranFOTO']; ?>" width="80"></p>
                        <?php } else {
                            echo "<p>Foto saat ini: Tidak ada foto</p>";
                        } ?>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <input type="submit" name="Update" class="btn btn-primary" value="Update">
                        <a href="restoran.php" class="btn btn-secondary">Batal</a>
                    </div>
                </div>
            </form>
            <br>
        </div>

        <div class="col-sm-1"></div>
    </div>

    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
</body>

</html>
